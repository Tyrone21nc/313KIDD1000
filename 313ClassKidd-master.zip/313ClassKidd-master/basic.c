//#include <stdio.h> 


int a = 1;
char c = 'a';
float f = 1.23456;
char string[] = "the bear at the grub"; 

int main(){ 

int i;
for(i=0; i<10; i++){a=a;}

}
